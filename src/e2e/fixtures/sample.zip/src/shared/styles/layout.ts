// 공통 높이 토큰
export const HEADER_H = 56;
export const BAR_H = 32; // 탭바/트리 툴바 공통 높이
