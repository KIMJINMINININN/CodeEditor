export { default } from "./ui/Tabs";
