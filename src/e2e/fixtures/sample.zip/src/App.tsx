// src/App.tsx
import AppRoot from "@app/index";
export default function App() {
  return <AppRoot />;
}
