// src/pages/workspace/index.ts
export { default } from "./ui/WorkspacePage";
