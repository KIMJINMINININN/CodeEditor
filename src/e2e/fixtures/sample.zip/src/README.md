### option 추가
1. zip 파일 업로드시에, root 리렉토리 바로 아래에 있는 1depth에 있는 폴더들은 다볼수있게끔 추가
2. 디자인 제공해준 이미지와 비슷하게 수정 및 아이콘 수정
3. 새파일, 새폴더, 삭제 기능 추가

### 해보고싶은것
1. 파일 드래그 앤 드롭으로 폴더간에 이동시키기.
2. 


## Test
```
📌 2) FSD에서 테스트 파일 배치 규칙(추천)
페이지(Unit): src/pages/workspace/ui/__tests__/WorkspacePage.test.tsx
위젯(Unit): src/widgets/<widget>/ui/__tests__/*.test.tsx
피처(Unit): src/features/<feature>/ui/__tests__/*.test.tsx
엔티티(Unit): src/entities/<entity>/model/__tests__/*.test.ts (store/selector 로직)
공용 테스트 유틸: src/shared/test/render.tsx, src/setupTests.ts
``
