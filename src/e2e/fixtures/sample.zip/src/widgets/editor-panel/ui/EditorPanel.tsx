// src/widgets/editor-panel/ui/EditorPanel.tsx
import Tabs from "@features/tabs";

export default function EditorPanel() {
  return <Tabs />;
}
