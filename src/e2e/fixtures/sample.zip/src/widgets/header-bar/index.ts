// src/widgets/header-bar/index.ts
export { default } from "./ui/HeaderBar";
